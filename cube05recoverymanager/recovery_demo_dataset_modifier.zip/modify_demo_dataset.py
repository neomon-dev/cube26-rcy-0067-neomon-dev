
from pathlib import Path
import pandas as pd
import shutil
from datetime import datetime

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
FEE = DATA / "fee_report_sample.csv"
UP = DATA / "upstream"

if not FEE.exists():
    raise FileNotFoundError(FEE)

backup = DATA / "backup_before_demo_dataset"
backup.mkdir(exist_ok=True)

for p in [FEE, *UP.glob("*.csv")]:
    shutil.copy2(p, backup / p.name)

fee = pd.read_csv(FEE, dtype=str).fillna("")

# ------------------------------------------------------------
# 1. Add explicit inbound defect subtypes.
# ------------------------------------------------------------
subtypes = {
    "FEE-0014-1": "inbound_defect_unbagged",
    "FEE-0018-1": "missing_suffocation_warning",
    "FEE-0026-1": "unscannable_barcode",
    "FEE-0035-1": "manufacturer_barcode_visible",
    "FEE-0061-1": "unplanned_prep_labelling",
    "FEE-0071-1": "unplanned_prep_bagging",
    "FEE-0074-1": "inbound_defect_unbagged",
    "FEE-0095-1": "unplanned_prep_bagging",
    "FEE-0096-1": "unscannable_barcode",
}

for charge_id, subtype in subtypes.items():
    mask = fee["charge_id"].astype(str) == charge_id
    if mask.any():
        fee.loc[mask, "charge_subtype"] = subtype
        fee.loc[mask, "description"] = subtype

# ------------------------------------------------------------
# 2. Make a deliberate mix:
#
# CLAIM cases:
#   0014, 0026, 0035, 0061, 0071
#
# REVIEW / NOT CLAIM:
#   0018 = warning present
#   0074 = insufficient/uncertain
#   0095 = bagging evidence contradicts
#   0096 = barcode uncertain
#
# 3. Ensure claim amounts are positive.
# ------------------------------------------------------------
amounts = {
    "FEE-0014-1": "2.00",
    "FEE-0018-1": "1.00",
    "FEE-0026-1": "1.00",
    "FEE-0035-1": "0.50",
    "FEE-0061-1": "2.00",
    "FEE-0071-1": "1.00",
    "FEE-0074-1": "0.50",
    "FEE-0095-1": "0.50",
    "FEE-0096-1": "2.00",
}

for charge_id, amount in amounts.items():
    mask = fee["charge_id"].astype(str) == charge_id
    if mask.any():
        fee.loc[mask, "amount_usd"] = amount
        if "amount" in fee.columns:
            fee.loc[mask, "amount"] = amount
        if "amount_total" in fee.columns:
            fee.loc[mask, "amount_total"] = amount
        if "amount_per_unit" in fee.columns:
            fee.loc[mask, "amount_per_unit"] = amount

fee.to_csv(FEE, index=False)

# ------------------------------------------------------------
# 4. Modify existing upstream evidence only.
# ------------------------------------------------------------
def load_source(name):
    candidates = list(UP.glob(f"*{name}*.csv"))
    if not candidates:
        raise FileNotFoundError(f"No {name} CSV found in {UP}")
    return candidates[0]

prep_path = load_source("prep")
prep = pd.read_csv(prep_path, dtype=str).fillna("")

def set_prep(unit_id, **values):
    mask = prep["unit_id"].astype(str) == unit_id
    if not mask.any():
        raise ValueError(f"{unit_id} not found in {prep_path.name}")
    for col, value in values.items():
        if col not in prep.columns:
            raise ValueError(f"Column {col!r} missing from {prep_path.name}")
        prep.loc[mask, col] = value

# CLAIM: explicit failure evidence
set_prep("UNIT-0014", polybag_present_sealed="no")

# REVIEW: evidence contradicts the missing-warning claim
set_prep("UNIT-0018", suffocation_warning="legible")

# CLAIM: invalid barcode placement
set_prep("UNIT-0026", fnsku_label_placement="invalid")

# CLAIM: manufacturer barcode remains visible
set_prep("UNIT-0035", original_barcode_covered="no")

# CLAIM: label placement invalid/missing
set_prep("UNIT-0061", fnsku_label_placement="missing")

# CLAIM: bagging required but absent
set_prep("UNIT-0071", polybag_present_sealed="no")

# REVIEW: deliberately uncertain evidence
set_prep("UNIT-0074", polybag_present_sealed="uncertain")

# REVIEW: compliant bagging contradicts the bagging-fee claim
set_prep("UNIT-0095", polybag_present_sealed="yes")

# REVIEW: uncertain barcode evidence
set_prep("UNIT-0096", fnsku_label_placement="uncertain")

prep.to_csv(prep_path, index=False)

print()
print("DEMO DATASET UPDATED")
print("====================")
print(f"Fee report: {FEE}")
print(f"Prep evidence: {prep_path}")
print(f"Backup: {backup}")
print()
print("Inbound defect cases:")
for charge_id, subtype in subtypes.items():
    print(f"  {charge_id}: {subtype}")
print()
print("Expected pattern:")
print("  Several evidence-supported claims")
print("  Several contradicted/uncertain cases sent to review")
print("  Unsupported fulfilment fees remain review")
print()
print("Run:")
print("  python -u evaluate.py")
